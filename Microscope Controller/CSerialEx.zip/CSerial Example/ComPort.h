// ComPort.h: interface for the CComPort class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMPORT_H__AD0D66F0_D7CC_11D2_8E68_006008A8250F__INCLUDED_)
#define AFX_COMPORT_H__AD0D66F0_D7CC_11D2_8E68_006008A8250F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CComPort  
{
public:
	CComPort(CString& sComPort);
	virtual ~CComPort();
	BOOL Initialize();
	void Read(CString& sResult);
	void Terminate();

protected:
	CString	m_sComPort;
	BOOL	m_bPortReady;
	HANDLE	m_hCom;
	DCB		m_dcb;
	COMMTIMEOUTS m_CommTimeouts;

};

#endif // !defined(AFX_COMPORT_H__AD0D66F0_D7CC_11D2_8E68_006008A8250F__INCLUDED_)
